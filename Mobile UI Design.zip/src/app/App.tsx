import { useState } from 'react';
import { Home, Users, MessageCircle, Users2, Search, Bell, Menu, User } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './components/ui/avatar';
import { Input } from './components/ui/input';
import { Badge } from './components/ui/badge';
import { Card, CardContent } from './components/ui/card';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [notificationCount] = useState(3);

  return (
    <div className="size-full flex flex-col bg-gray-50">
      {/* Top Navigation Bar */}
      <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        {/* Profile Avatar */}
        <Avatar className="h-10 w-10">
          <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop" alt="Profile" />
          <AvatarFallback>
            <User className="h-5 w-5" />
          </AvatarFallback>
        </Avatar>

        {/* Search Bar */}
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            type="search"
            placeholder="Search"
            className="pl-10 bg-gray-100 border-0 rounded-lg"
          />
        </div>

        {/* Notification Icon */}
        <button className="relative p-2 hover:bg-gray-100 rounded-lg">
          <Bell className="h-5 w-5 text-gray-700" />
          {notificationCount > 0 && (
            <Badge
              variant="destructive"
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
            >
              {notificationCount}
            </Badge>
          )}
        </button>

        {/* Settings Menu */}
        <button className="p-2 hover:bg-gray-100 rounded-lg">
          <Menu className="h-5 w-5 text-gray-700" />
        </button>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-20">
        <div className="p-4 space-y-4">
          {activeTab === 'home' && (
            <>
              {/* Sample Post Card */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3 mb-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop" alt="User" />
                      <AvatarFallback>U</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold text-sm">Sarah Johnson</h3>
                      <p className="text-xs text-gray-500">Software Engineer • 2h ago</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-800 mb-3">
                    Excited to share my latest project! Just launched a new feature that improves user experience by 40%. 🚀
                  </p>
                  <img
                    src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=500&h=300&fit=crop"
                    alt="Post"
                    className="w-full h-48 object-cover rounded-lg mb-3"
                  />
                  <div className="flex items-center gap-4 text-gray-500 text-sm">
                    <button className="flex items-center gap-1 hover:text-blue-600">
                      <span>👍</span>
                      <span>24</span>
                    </button>
                    <button className="flex items-center gap-1 hover:text-blue-600">
                      <MessageCircle className="h-4 w-4" />
                      <span>8</span>
                    </button>
                    <button className="flex items-center gap-1 hover:text-blue-600">
                      <span>🔄</span>
                      <span>3</span>
                    </button>
                  </div>
                </CardContent>
              </Card>

              {/* Another Sample Post */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3 mb-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop" alt="User" />
                      <AvatarFallback>M</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold text-sm">Michael Chen</h3>
                      <p className="text-xs text-gray-500">Product Designer • 5h ago</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-800 mb-3">
                    Design tips: Always start with user research before jumping into wireframes. Understanding your users is key! 💡
                  </p>
                  <div className="flex items-center gap-4 text-gray-500 text-sm">
                    <button className="flex items-center gap-1 hover:text-blue-600">
                      <span>👍</span>
                      <span>42</span>
                    </button>
                    <button className="flex items-center gap-1 hover:text-blue-600">
                      <MessageCircle className="h-4 w-4" />
                      <span>15</span>
                    </button>
                    <button className="flex items-center gap-1 hover:text-blue-600">
                      <span>🔄</span>
                      <span>7</span>
                    </button>
                  </div>
                </CardContent>
              </Card>
            </>
          )}

          {activeTab === 'network' && (
            <div className="text-center py-12">
              <Users className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h2 className="text-lg font-semibold text-gray-800 mb-2">Your Network</h2>
              <p className="text-sm text-gray-500">Connect with professionals in your field</p>
            </div>
          )}

          {activeTab === 'chat' && (
            <div className="text-center py-12">
              <MessageCircle className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h2 className="text-lg font-semibold text-gray-800 mb-2">Messages</h2>
              <p className="text-sm text-gray-500">Start a conversation with your connections</p>
            </div>
          )}

          {activeTab === 'club' && (
            <div className="text-center py-12">
              <Users2 className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h2 className="text-lg font-semibold text-gray-800 mb-2">Clubs</h2>
              <p className="text-sm text-gray-500">Join communities and groups</p>
            </div>
          )}
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-gray-200 fixed bottom-0 left-0 right-0 px-4 py-2 flex items-center justify-around">
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center gap-1 py-2 px-4 rounded-lg transition-colors ${
            activeTab === 'home' ? 'text-blue-600' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Home className={`h-6 w-6 ${activeTab === 'home' ? 'fill-current' : ''}`} />
          <span className="text-xs font-medium">Home</span>
        </button>

        <button
          onClick={() => setActiveTab('network')}
          className={`flex flex-col items-center gap-1 py-2 px-4 rounded-lg transition-colors ${
            activeTab === 'network' ? 'text-blue-600' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Users className={`h-6 w-6 ${activeTab === 'network' ? 'fill-current' : ''}`} />
          <span className="text-xs font-medium">Network</span>
        </button>

        <button
          onClick={() => setActiveTab('chat')}
          className={`flex flex-col items-center gap-1 py-2 px-4 rounded-lg transition-colors ${
            activeTab === 'chat' ? 'text-blue-600' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <MessageCircle className={`h-6 w-6 ${activeTab === 'chat' ? 'fill-current' : ''}`} />
          <span className="text-xs font-medium">Chat</span>
        </button>

        <button
          onClick={() => setActiveTab('club')}
          className={`flex flex-col items-center gap-1 py-2 px-4 rounded-lg transition-colors ${
            activeTab === 'club' ? 'text-blue-600' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <Users2 className={`h-6 w-6 ${activeTab === 'club' ? 'fill-current' : ''}`} />
          <span className="text-xs font-medium">Club</span>
        </button>
      </nav>
    </div>
  );
}
